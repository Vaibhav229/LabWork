export interface Employee {

    id: number
    name: string
    salary: number
    department: string

}